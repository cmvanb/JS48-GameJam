'use strict';

define([], function ()
{
    var Constants = {};

    Constants.DEBUG = false;

    Constants.GRAVITY = 2000;

    return Constants;
});
